"""Allow running as python -m qtmcp."""

from qtmcp.cli import main

main()
