"""QtMCP - MCP server for controlling Qt applications."""

__version__ = "0.1.0"
